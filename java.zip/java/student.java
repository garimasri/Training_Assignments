import java.util.*;
class student implements Comparable<student>
{
	String name;
	int rollno;
	double cgpa;
	student(){}
	student(String n,int r,double c)
	{
		name=n;
		rollno=r;
		cgpa=c;
	}
	public String toString()
	{
		return "name="+name+ "rollno ="+rollno+"cgpa="+cgpa;
	}
	public int compareTo(student s)
	{
		return this.rollno-s.rollno;
	}
}
class CollectionC
{
	public static void main(String[] ar)
	{
		ArrayList<student> l=new ArrayList<student>();
		l.add(new student("ankur",110,9.56));
		l.add(new student("garima",102,2.4));
		Collection.sort(l);
		System.out.println(l);
		Iterator itr=l.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}
