import java.util.Scanner;
class in
{
public static void main(String[] args)
{
	int a;
	System.out.println("enter");
	Scanner ab=new Scanner(System.in);
	a=ab.nextInt();
	System.out.println(a);
}
}