interface an
{
	void anjali();
}
class abinter2
{
	public static void main(String[] a)
	{
		an o=new an()
		{
			public void anjali()
			{
				System.out.println("irreplacable");
			}
		};
		o.anjali();
	}
}