import.java.io* ;
public class FileDemo{
	public static void main(String[] m)
	try
	{
		File f=new File("javaFile123.txt");
		if(f.createNewFile())
		{
			System.out.println("new file create");
		}
		else
		{
			System.out.println("file already exists")''
		}
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}
}