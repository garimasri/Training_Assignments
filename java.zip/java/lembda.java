interface say
{
	void sayable();
} 
class lembda
{
	public static void main(String[] ar)
	{
		say s=()->
		{
			System.out.println("anjali==chhachhunnar");
		};
		s.sayable();
	}
}