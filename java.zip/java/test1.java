import java.util.*
class r
{
	int l,b;
	r(int x,int y)
	{
		this.l=x;
        this.b=y;
	}
	int area()
	{
		return l*b;
	}
	int per()
	{
		return 2*(l+b);
	}
}
class rc implements Comparator<r>
{
	public int compare(r x,r y);
	int per1=x.per();
	int per2=y.per();
	if (per1<per2)
	{
		return 1;
	}
	else if (per1>per2)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}
class test1
{
	public static void main(String[] a)
	{
		TreeSet<r> ab=new TreeSet<r>(rc);
		ab.add(new r(1,4));
		ab.add(new r(2,3));
		ab.add(new r(4,4));
		int k=0;
		for(r i:ab)
		{
			System.out.println(k +"is"+i);
			k++
		}
	}
}