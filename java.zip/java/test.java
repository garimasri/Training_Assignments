abstract class shape
{
	abstract double area();
	abstract double peri();
}
class rec extends shape
{
	double len,wid;
	rec(double len, double wid)
	{
     this.len=len;
     this.wid=wid;
	}
	double area()
	{
		return len*wid;
	}
	double peri()
	{
		return 2*(len+wid);
	}
}
class test
{
	public static void main(String ar[])
	{
		rec r=new rec(10,20);
		System.out.println("Area:" +r.area());
		System.out.println("Peri :" + r.peri());
	}
}