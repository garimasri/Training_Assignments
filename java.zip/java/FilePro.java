class FilePro
{
	public static void main(String[] args) throws IOException
	{
 String fn=args[0];
 File f=new File(fn);
 File f1=new File("testABC.text");
 f.createNewFile();
 System.out.println(f.getName());
 System.out.println(f.getPath());
 System.out.println(new java.util.Date(f.lastModified());
 	System.out.println(f.getAbsolutePath());
 	System.out.println(f.getCanonicalPath());
 	System.out.println(f.getParent());
 	System.out.println(f.exists());
 	if(f.exists())
 	{
 		System.out.println(f.canWrite());
 		System.out.println(f.canRead());
 		System.out.println(f.isDirectory());
 		System.out.println(f.length());
 	}

System.out.println(f.renameTo(f1));

	}
}