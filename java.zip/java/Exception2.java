class Exception2
{
	public static void main(String arg[])
	{
		try
		{
			int a=Integer.parseInt(arg[0]);
			int b=Integer.parseInt(arg[1]);
			int c=a/b;
			System.out.println(c);
		}
		catch(Throwable e)
		{
			System.out.println(e);
		}
	}
}