import java.util.Scanner;
class MyException extends Exception{
	double r;
	public MyException(double radious)
	{
		this.r=radious;
		System.out.println("invalid range" +r);
	}
}
class myex
{
	public static void main(String[] a)
	{
		try
		{
		Scanner s=new Scanner(System.in);
         double radious=s.nextDouble();
         if(radious<0)
         {
         	throw new MyException(radious);
         }
         System.out.println(3.14*radious*radious);
		}
		catch(MyException e)
		{
			System.out.println("ksl" +e);
		}
	}
}