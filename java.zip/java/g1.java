class a
{ 
	int b;
	class nestedstatic
	{
		public void display()
		{
			/*a o=new a();
			o.b=10;*/
			System.out.println(b);
			System.out.println("static nested");
		}
	}
}
class g1
{
	public static void main(String[] ae)
	{
		a o=new a();
		a.nestedstatic ar=o.new nestedstatic();
		ar.display();
	}
}