import java.util.Scanner;
class exception
{
public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
		try
		{
			System.out.println("enter no");
			int a=sc.nextInt();
			System.out.println("enter no");
			int b=sc.nextInt();
			int c=a/b;
			System.out.println("result is:"+c);
		}
		catch(ArithmeticException e)
		{
			System.out.println("cannot divided by zero");
		}
	}
}