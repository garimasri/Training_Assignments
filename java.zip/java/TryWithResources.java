import java.io.FileOutputStream;
public class TryWithResources
{
	public static void main(String args[])
	{
		try(FileOutputStream f=new FileOutputStream("abc.txt"))
		{
			String m="welcome to java";
			byte 
		}
	}
}