import java.util.*;
class Employee
{
	 String name;
	 int id;
	 double salary;
	 Employee(){}
	 Employee(String name, int id, double salary)
	 {
	 	this.name=name;
	 	this.id=id;
	 	this.salary=salary;
	 }
	 public String toString()
	 {
	 	return "name="+name+"id="+id+"salary="+salary;
	 }
}
class SortById implements Comparator<Employee>
{
	public int compare(Employee e1,Employee e2)
	{
   return(e1.id>e2.id?1:-1);
	}
}
class s1
{
	public static void main(String[] ar)
	{
		ArrayList<Employee> al=new ArrayList<Employee>();
		al.add(new Employee("rohit",12,12000));
		al.add(new Employee("rohit1",11,11000));
        al.add(new Employee("rohit2",12,10000));
        System.out.println(al);
        Collections.sort(al,new SortById());
         System.out.println(al);
         Collections.sort(al,new SortById());
          System.out.println(al);
	}
}