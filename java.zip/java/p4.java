import java.io.*;
public static void main(String[] args)
try{
MyClass object1=new MyClass("hello",-7,2.7e10);
System.out.println("object:"+object.toString());
FileOutputStream fos=new FileOutputStream("serial.txt");
ObjectOutputStream oos=new ObjectOutputStream(fos);
oos.writeObject(object1);
oos.flush();
oos.close();
}
catch(IOException e)
{
	System.out.println("exception "+e);
	System.exit(0);
}
}
}