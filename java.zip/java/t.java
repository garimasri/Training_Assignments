import java.util.*;
class t
{
	public static void main(String[] m)
	{
		Deque<String> a=new LinkedList<String>();
		a.offer("garima");
		a.offer("anjali");
		a.offer("priyanka");
		System.out.println(a);
		a.offerFirst("wafi");
		System.out.println(a);
	}
}