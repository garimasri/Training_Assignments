import java.util.Scanner;
class exception4
{
	public static void main(String[] ma)
	{
		try
		{
			fun();
		}
		catch(IllegalArgumentException e)
		{
			System.out.println("jhdgisag");
		}
	}
	static void fun()
	{
		try
		{
        Scanner sc=new Scanner(System.in);
        int val=sc.nextInt();
        if(val<0)
        {
        	throw new IllegalArgumentException();
        }
		}
		catch(IllegalArgumentException e)
		{
			throw e;
			}
		}
}