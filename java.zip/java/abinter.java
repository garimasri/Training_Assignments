interface g
{
	void show();
}
class abinter
{
	public static void main(String [] a)
	{
	g s=new g()
	{
		public void show()
		{
			System.out.println("red");
		}
	};
	s.show();
}
}