import java.io.*;
public class DataStream
{
	public static void main(String[] m)throws IOException
	{
		//File fi=new File("text.txt");
		//FileInputStream fin=new FileInputStream(fi);
		FileInputStream fin=new FileInputStream("text.txt");
		int i=fin.read();
		System.out.print((char)i);
		fin.close();
	}
}