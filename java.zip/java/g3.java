class a
{ 
	void d()
	{
		nestedstatic n=new nestedstatic();
		n.display();
	}
	static class nestedstatic
	{
		public void display()
		{
			/*a o=new a();
			o.b=10;*/
			System.out.println("static nested");
		}
	}
}
class g3
{
	public static void main(String[] ae)
	{
	a o=new a();
	o.d();
	}
}