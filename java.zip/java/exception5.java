class exception5
{
	public static void main(String[] ar)
	{
		try
		{
			method1();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	static void method1() throws Exception{
		try
		{
			method2();
		}
		catch(Exception e)
		{
			throw new Exception("a" ,e);
		}
	}
	static void method2() throws Exception{
		throw new Exception("m");
	}
}