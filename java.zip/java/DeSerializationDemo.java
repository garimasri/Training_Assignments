import java.io.*;
public class DeSerializationDemo
{
	public static void main(String[] m)
	{
		try
		{
			MyClass object2;
			FileInputStream fis=new FileInputStream("serial.txt");
			ObjectInputStream ois=new ObjectInputStream(fis);
			object2 =(MyClass)ois.readObject();
			ois.close();
			System.out.println("object2:"+object);
		}
		catch(Exception e);
	}
}