class an
{
	int a=20;
	public void show()
	{
		System.out.println("anjali==love");
	}
}
class anclass
{
	public static void main(String[] aa)
	{
		an ag=new an()
		{
			public void show()
			{
				System.out.println("anjali==irreplacable");
			}
		};
		ag.show();
       System.out.println(ag.a);
	}
}