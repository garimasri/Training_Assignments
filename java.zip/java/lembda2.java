interface say
{
	void sayable();
}
class lembda2
{
public static void main(String[] ar)
{
	display(
		()->{System.out.println("garima");});
}
static void display(say s)
	{
		s.sayable();
	}
}	