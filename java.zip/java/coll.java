import java.util.*;
class coll{
	public static void main(String [] args)
	{
		TreeSet<String> tree=new TreeSet<String>();
		tree.add("garima");
		tree.add("anjali");
		tree.add("priyanka");
		tree.add("wafi");
		tree.add("anjali");
		Iterator<String> itr=tree.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}